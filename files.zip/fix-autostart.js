const fs = require('fs');

// Add autostart setting to Settings panel
let settings = fs.readFileSync('src/components/NowPlayingSettings.tsx', 'utf8');

// Add autostart section to the settings component
settings = settings.replace(
  'export default function NowPlayingSettings() {',
  `import { enable, disable, isEnabled } from "@tauri-apps/plugin-autostart";

export default function NowPlayingSettings() {
  const [autostart, setAutostart] = React.useState(false);

  React.useEffect(() => {
    isEnabled().then(setAutostart).catch(() => {});
  }, []);

  const toggleAutostart = async () => {
    try {
      if (autostart) { await disable(); setAutostart(false); }
      else { await enable(); setAutostart(true); }
    } catch (e) { console.error('Autostart error:', e); }
  };`
);

// Add React import if missing
if (!settings.includes("import React")) {
  settings = 'import React from "react";\n' + settings;
}

fs.writeFileSync('src/components/NowPlayingSettings.tsx', settings);
console.log('Done');
